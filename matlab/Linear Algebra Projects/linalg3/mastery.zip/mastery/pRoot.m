function T12 = pRoot(T)

[evals, ~] = wilkinsonQR(T); 

D12 = diag(sqrt(evals)); 

X = invItr(T, evals);

T12 = X * D12 * X';
