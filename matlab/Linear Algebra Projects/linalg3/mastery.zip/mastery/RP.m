function [R, CS] = RP (R) 

N = length(R); 

CS = zeros(N - 1, 2); 

for j = 1 : N - 1 
   
   [c,s] = givens(R(j, j), R(j + 1, j)); 
   
   P = [c s; -s c]; 
   
   R([j, j + 1], j:min(j + 2, N)) = P' *  R([j, j + 1], j:min(j + 2, N));
   
   CS(j,:) = [c,s];
   
end

% Q = eye(N); 
%for  j =  1 : N - 1
%    
%    P = [CS(j, 1), CS(j, 2); - CS(j, 2), CS(j, 1)]; 
%
%    Q(:, [j, j + 1]) = Q(:, [j, j + 1]) * P;
%end
