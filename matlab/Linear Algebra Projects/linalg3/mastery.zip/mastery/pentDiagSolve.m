function [w] = pentDiagSolve (R, v)


N = length(v); 

for k = 1 : N - 2
    
   [c, s] = givens(R(k + 1, k), R(k + 2, k));  

   P = [c s; -s c]; 

   R([k + 1, k + 2], k:min(k + 5, N)) = P' *  R([k + 1, k + 2], k:min(k + 5, N));
   
   v(k + 1: k + 2) = P' * v(k + 1: k + 2);

end

for j = 1 : N - 1 

   [c, s] = givens(R(j, j), R(j + 1, j));

   P = [c s; -s c];

   R([j, j + 1], j:min(j + 7, N)) = P' *  R([j, j + 1], j:min(j + 7, N));
   
   v(j: j + 1) = P' * v(j: j + 1);

end


w = bandBacksub(R, v, 5); 
